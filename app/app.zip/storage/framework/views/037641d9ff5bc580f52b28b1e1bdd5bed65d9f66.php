<?php $__env->startSection('content'); ?>
    <div class="h-[60rem] flex flex-col justify-center items-center">
        <h1 class="text-4xl font-bold text-custom-green text-center">Coming Soon!</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Projects\Karwan e Pakistan\app\resources\views/events.blade.php ENDPATH**/ ?>