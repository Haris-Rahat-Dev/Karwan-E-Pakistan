<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Karwan-e-Pakistan Trust</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/stylesheet.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset("./favicon-32x32.png")); ?>" type="image/x-icon">
    <script src="https://kit.fontawesome.com/bde7c7e20a.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50">
<div class="flex flex-col justify-center items-center mt-32">
    <div class="w-3/12 bg-white p-6 rounded-lg shadow-2xl">
        <div class="flex flex-row justify-center items-center">
            <img src="<?php echo e(asset("./assets/logo.png")); ?>" alt="" class="w-24 h-24">
        </div>
        <h1 class="text-2xl text-custom-green text-center mb-4">Register</h1>
        <form action="<?php echo e(route('Register')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <input type="text" name="name" placeholder="Your Name" class="bg-gray-00 border-2 border-custom-green w-full p-4 rounded-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="my-4">
                <p class="text-lg text-red-500"><?php echo e($message); ?></p>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mb-4">
                <input type="text" name="email" placeholder="Your Email" class="bg-gray-00 border-2 border-custom-green w-full p-4 rounded-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="my-4">
                <p class="text-lg text-red-500"><?php echo e($message); ?></p>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mb-4">
                <input type="password" name="password" placeholder="Password" class="bg-gray-00 border-2 border-custom-green w-full p-4 rounded-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="my-4">
                <p class="text-lg text-red-500"><?php echo e($message); ?></p>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div>
                <button type="submit" class="text-xl rounded text-custom-green bg-gray-50 hover:text-white hover:bg-custom-green p-3 border border-custom-green">Register</button>
            </div>
        </form>
    </div>
    <div class="m-6">
        <a href="<?php echo e(route('LoginView')); ?>"><button class="text-xl rounded text-custom-green bg-gray-50 hover:text-white hover:bg-custom-green p-3 border border-custom-green">Back to Login</button></a>
    </div>
</div>
</body>
</html>
<?php /**PATH D:\Web Projects\Karwan e Pakistan\app\resources\views/admin/register.blade.php ENDPATH**/ ?>