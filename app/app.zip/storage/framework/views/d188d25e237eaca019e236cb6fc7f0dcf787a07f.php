<?php $__env->startComponent('mail::message'); ?>
From, <?php echo e($data->name); ?><br>
Email: <?php echo e($data->email); ?><br>
Message:<br>
<?php echo e($data->message); ?>






<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Web Projects\Karwan e Pakistan\app\resources\views/mail/message.blade.php ENDPATH**/ ?>