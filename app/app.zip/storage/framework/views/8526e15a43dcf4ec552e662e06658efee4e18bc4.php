<?php $__env->startSection('content'); ?>
    <div>
        <div data-aos="zoom-in" data-aos-duration="1000">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register-form', [])->html();
} elseif ($_instance->childHasBeenRendered('gTi4bsw')) {
    $componentId = $_instance->getRenderedChildComponentId('gTi4bsw');
    $componentTag = $_instance->getRenderedChildComponentTagName('gTi4bsw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gTi4bsw');
} else {
    $response = \Livewire\Livewire::mount('register-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('gTi4bsw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Projects\Karwan e Pakistan\app\resources\views/register.blade.php ENDPATH**/ ?>