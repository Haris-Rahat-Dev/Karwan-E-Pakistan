<div class="w-full flex flex-col justify-center items-center my-8 md:w-[90%] md:py-24 lg:w-[90%] lg:py-24" >
    <?php if($show): ?>
        <div class="py-6 text-custom-green text-center text-2xl flex flex-row justify-center items-center" data-aos="fade-left" data-aos-duration="2000">
            <div class="w-[21rem] bg-white rounded flex flex-row justify-between items-center">
                <p class="pl-4"><?php echo e(session('message')); ?></p>
                <span class="material-icons md-24 p-4 cursor-pointer hover:bg-custom-green hover:text-white hover:border hover:border-white" wire:click="showFalse">close</span>
            </div>
        </div>
    <?php endif; ?>
    <form wire:submit.prevent="submitForm" action="" class="bg-white border-1 border-custom-green shadow-2xl rounded p-12" style="z-index: 99">
        <h1 class="md:text-xl lg:text-3xl text-custom-green text-center mb-10">Don't feel like registering? Send us a Message, and we'll get back to you as soon as possible!</h1>
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <input type="text" placeholder="Name" wire:model.defer="name" name="name" value="<?php echo e(old('name')); ?>" class="bg-gray-00 border-2 border-custom-green w-full p-4 rounded-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="my-4">
                <p class="text-xl text-red-500"><?php echo e($message); ?></p>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-4">
            <input type="email" placeholder="Email" wire:model.defer="email" name="email" value="<?php echo e(old('email')); ?>" class="bg-gray-00 border-2 border-custom-green w-full p-4 rounded-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="my-4">
                <p class="text-xl text-red-500"><?php echo e($message); ?></p>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-4">
            <textarea type="text" placeholder="Message" wire:model.defer="message" name="message" class="bg-gray-00 border-2 border-custom-green w-full p-4 rounded-lg <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="my-4">
                <p class="text-xl text-red-500"><?php echo e($message); ?></p>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div wire:loading wire:target="submitForm" class="pb-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: rgb(255, 255, 255) none repeat scroll 0% 0%; display: block; shape-rendering: auto;" width="200px" height="200px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                <circle cx="50" cy="50" fill="none" stroke="#06713b" stroke-width="10" r="35" stroke-dasharray="164.93361431346415 56.97787143782138">
                    <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" values="0 50 50;360 50 50" keyTimes="0;1"></animateTransform>
                </circle></svg></div>
        <div class="mb-4 flex flex-col justify-center ">
            <button type="submit" class="flex flex-row justify-center items-center text-xl rounded text-custom-green border border-2 border-custom-green bg-gray-50 hover:text-white hover:bg-custom-green p-3">
                <span class="material-icons md-24 pr-2">send</span>
                Message
            </button>
        </div>
    </form>
</div>
<?php /**PATH D:\Web Projects\Karwan e Pakistan\app\resources\views/livewire/contact-form.blade.php ENDPATH**/ ?>