<?php $__env->startSection('content'); ?>
    <div>
        <div class="flex flex-row justify-center items-center">
            <h1 class="my-8 p-4 text-2xl md:my-8 md:text-3xl lg:my-8 lg:text-4xl text-white border-2 border-custom-green bg-custom-green w-[25rem] rounded text-center">KEP Supreme Council</h1>
        </div>
        <div class="grid grid-cols-1 gap-y-8 md:grid-cols-3 md:gap-x-11 md:gap-y-12 lg:grid-cols-5 lg:gap-x-40 lg:gap-y-16 p-12">
            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border border-custom-green shadow-2xl text-center rounded" data-aos="fade-up" data-aos-duration="<?php echo e(600+($loop->index*100)); ?>">
                    <img src="<?php echo e(asset('storage/'.$one->picture)); ?>" class="w-full h-64" alt="">
                    <div class="p-4">
                        <p class="text-lg"><?php echo e($one->name); ?></p>
                        <p class="font-bold text-xl text-custom-green"><?php echo e($one->role); ?></p>
                        <p class="text-xl">Karwan E Pakistan Trust</p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Projects\Karwan e Pakistan\app\resources\views/ourTeam.blade.php ENDPATH**/ ?>