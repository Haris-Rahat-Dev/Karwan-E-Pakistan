@extends('layouts.app')
@section('content')
    <div class="h-[60rem] flex flex-col justify-center items-center">
        <h1 class="text-4xl font-bold text-custom-green text-center">Coming Soon!</h1>
    </div>
@endsection
