@extends('layouts.app')
@section('content')
    <div>
        <div data-aos="zoom-in" data-aos-duration="1000">
            <livewire:register-form/>
        </div>
    </div>
@endsection
