<?php return array (
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'register-form' => 'App\\Http\\Livewire\\RegisterForm',
);